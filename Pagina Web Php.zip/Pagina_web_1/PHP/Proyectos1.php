<!DOCTYPE html>
<htmal lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut-icon" href="Imagen1.jpg" type="image/x-icon">
    <title>Proyecto</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../css/proyecto.css">
    <script src="https://kit.fontawesome.com/946a6ba5b0.js" crossorigin="anonymous"></script>
</head>
<body>
      
    <header class="header">

        <div class="menu container">
            <a href="#" class="logo"></a>
            <input type="checkbox" id="menu" />
            <label fro="menu">
                <img src="../Img/menu.png" class="menu-icono" alt="menu" width="100px" height="100px">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="../PHP/Admin.php">Inicio</a></li>
                    <li><a href="../PHP/Proyectos2.php">Añadir Cliente</a></li>
                    <li><a href="../PHP/contrato.php">Añadir Contrato</a></li>
                </ul>
            </nav>

            <div>
                <ul>
                    <li class="submenu">
                    <a href="index.html" class="btn btn-black"><i class="fas fa-user"></i></a>   
            </div>
        </div>

        <div class="header-content container">
            <div class="header-img">
                <img src="../Img/img5.jpg" alt="" width="500px" height="250px">
            </div>
            <div class="header-txt">
                <h1>Proyectos de calidad</h1>
                <p>conoce nuestros proyectos y unete a nosotros</p>
                <a href="../error404.html" class="btn-1">Mas informacion</a>
            </div>
        </div>
    
    </header>

    <section class="ofert container">
        <div class="ofert-1">
            <div class="ofert-img">
                <img src="../Img/img1.jpg" alt="">
            </div>
            <div class="ofert-txt">
                <h3>proyecto 1</h3>
                <a href="#" class="btn-2">Informacion</a>
            </div>
        </div>

        <div class="ofert-1">
            <div class="ofert-img">
                <img src="../Img/img2.jpg" alt="">
            </div>
            <div class="ofert-txt">
                <h3>proyecto 2</h3>
                <a href="#" class="btn-2">Informacion</a>
            </div>
        </div>

        <div class="ofert-1">
            <div class="ofert-img">
                <img src="../Img/img3.jpg" alt="">
            </div>
            <div class="ofert-txt">
                <h3>proyecto 3</h3>
                <a href="#" class="btn-2">Informacion</a>
            </div>
        </div>
    </section>

    <main class="proyect container" id="lista-1">
        <h2>productos</h2>

        <div class="proyect-content">

            <div class="proyect">
                <img src="../Img/img1.jpg" alt="">
                <div class="proyect-txt">
                    <h3>Trabajo 1</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam voluptas beatae repudiandae natus et veniam earum? Doloribus ab exercitationem, voluptates, fugit aspernatur explicabo porro dolore culpa excepturi sunt totam quaerat?</p>
                    <a href="error404.html" class="ver el proyecto" data-ida="1">Ver el proyecto</a>
                </div>
            </div>

            <div class="proyect">
                <img src="../Img/img4.jpg" alt="">
                <div class="proyect-txt">
                    <h3>Trabajo 2</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam voluptas beatae repudiandae natus et veniam earum? Doloribus ab exercitationem, voluptates, fugit aspernatur explicabo porro dolore culpa excepturi sunt totam quaerat?</p>
                    <a href="error404.html" class="ver el proyecto" data-ida="2">Ver el proyecto</a>
                </div>
            </div>

            <div class="proyect">
                <img src="../Img/img6.jpg" alt="">
                <div class="proyect-txt">
                    <h3>Trabajo 3</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam voluptas beatae repudiandae natus et veniam earum? Doloribus ab exercitationem, voluptates, fugit aspernatur explicabo porro dolore culpa excepturi sunt totam quaerat?</p>
                    <a href="error404.html" class="ver el proyecto" data-ida="3">Ver el proyecto</a>
                </div>
            </div>

            <div class="proyect">
                <img src="../Img/img7.jpg" alt="">
                <div class="proyect-txt">
                    <h3>Trabajo 4</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam voluptas beatae repudiandae natus et veniam earum? Doloribus ab exercitationem, voluptates, fugit aspernatur explicabo porro dolore culpa excepturi sunt totam quaerat?</p>
                    <a href="error404.html" class="ver el proyecto" data-ida="4">Ver el proyecto</a>
                </div>
            </div>

            <div class="proyect">
                <img src="../Img/img8.jpg" alt="">
                <div class="proyect-txt">
                    <h3>Trabajo 5</h3>
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam voluptas beatae repudiandae natus et veniam earum? Doloribus ab exercitationem, voluptates, fugit aspernatur explicabo porro dolore culpa excepturi sunt totam quaerat?</p>
                    <a href="error404.html" class="ver el proyecto" data-ida="5">Ver el proyecto</a>
                </div>
            </div>
            
        </div>
    </main>

    <footer>
        <div class="contenedor-footer">
           <div class="content-foo">
                <h4>Mapa de sitio</h4>
                <p><a href="Mapa de sitio.html">Mapa de sitio</a></p>
           </div>
           <div class="content-foo">
                <h4>email</h4>
                <p>serviciostopografic1@hotmail.com</p>
       </div> 
       <div class="content-foo">
            <h4>Redes</h4>
            <section class="buttons">
                <a href="https://www.facebook.com/profile.php?id=100092641494792" class="fa fa-facebook"></a>
                <a href="https://twitter.com/STopografi83139" class="fa fa-twitter"></a>
                <a href="https://www.instagram.com/stopograficos/?__coig_restricted=1" class="fa fa-instagram"></a>
            </section>
            
        </div>  
        </div>
        <h2 class="titulo-final">&copy; Servicios Topograficos | Gaes 7</h2>
    </footer>
</body>
</htmal>
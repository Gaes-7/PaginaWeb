<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["numero"]) and !empty($_POST["Duracion"])){
     

        $numero=$_POST["numero"];
        $duracion=$_POST["Duracion"];

        $sql=$conexion->query(" insert into permisos(NumPermiso, Duracion)values
        ('$numero','$duracion')");
        if ($sql==1){
            echo '<div class="alert alert-success">Cliente Registrada Correctamente</div>';
        }else {
        
            echo '<div class="alert alert-danger">Error Al Registrar Cliente</div>';
        }


    }else
        echo '<div class="alert alert-warning">Alguno de los campones estan vacios</div>';

}

?>
<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["nombre"]) and !empty($_POST["apellido"]) and !empty($_POST["telefono"]) and !empty($_POST["correo"])){
     
        $nombre=$_POST["nombre"];
        $apellido=$_POST["apellido"];
        $telefono=$_POST["telefono"];
        $correo=$_POST["correo"];

        $sql=$conexion->query(" insert into Cliente(NomCliente, ApeCliente, Telefono, Correo)values('$nombre','$apellido','$telefono', '$correo')");
        if ($sql==1){
            echo '<div class="alert alert-success">Cliente Registrada Correctamente</div>';
        }else {
        
            echo '<div class="alert alert-danger">Error Al Registrar Cliente</div>';
        }


    }else
        echo '<div class="alert alert-warning">Alguno de los campones estan vacios</div>';

}

?>
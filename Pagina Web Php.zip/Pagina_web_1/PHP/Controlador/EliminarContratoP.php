<?php

if (!empty($_GET["id"])) {
    $id=$_GET["id"];
    $sql=$conexion->query(" delete from contratoproyecto where idContratoProyecto=$id ");
    if ($sql == 1) {
        echo '<div class="alert alert-success"> Contrato Eliminado Correctamente </div>';
    } else {
        echo '<div class="alert alert-danger"> Error al eliminar contrato </div>';
    }
    
}


?>
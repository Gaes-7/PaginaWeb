<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["numero"]) and !empty($_POST["Estado"])){
     

        $numero=$_POST["numero"];
        $estado=$_POST["Estado"];

        $sql=$conexion->query(" insert into Certificados(NumCertificado, EstadoCertificadp)values
        ('$numero','$estado')");
        if ($sql==1){
            echo '<div class="alert alert-success">Cliente Registrada Correctamente</div>';
        }else {
        
            echo '<div class="alert alert-danger">Error Al Registrar Cliente</div>';
        }


    }else
        echo '<div class="alert alert-warning">Alguno de los campones estan vacios</div>';

}

?>
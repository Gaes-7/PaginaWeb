<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["fechaI"]) and !empty($_POST["fechaF"]) and !empty($_POST["valor"]) and !empty($_POST["clausula"])){
     
        $FechaI=$_POST["fechaI"];
        $FechaF=$_POST["fechaF"];
        $valor=$_POST["valor"];
        $clausula=$_POST["clausula"];

        $sql=$conexion->query(" insert into contratoproyecto (FechaInicio, FechaFin, Valor, Clausula)values
        ('$FechaI','$FechaF', '$valor','$clausula')");
        if ($sql==1){
            echo '<div class="alert alert-success">Contrato Registrada Correctamente</div>';
        }else {
        
            echo '<div class="alert alert-danger">Error Al Registrar Contrato</div>';
        }


    }else
        echo '<div class="alert alert-warning">Alguno de los campones estan vacios</div>';

}

?>
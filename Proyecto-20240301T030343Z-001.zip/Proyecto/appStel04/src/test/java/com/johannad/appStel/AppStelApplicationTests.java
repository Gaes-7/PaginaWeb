package com.johannad.appStel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppStelApplicationTests {

	@Test
	void contextLoads() {
	}

}

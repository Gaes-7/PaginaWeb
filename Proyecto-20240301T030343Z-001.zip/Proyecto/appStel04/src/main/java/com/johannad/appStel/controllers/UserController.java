package com.johannad.appStel.controllers;

import com.johannad.appStel.business.UserBusiness;
import com.johannad.appStel.dtos.UserDto;
import com.johannad.appStel.entity.Resident;
import com.johannad.appStel.entity.Role;
import com.johannad.appStel.entity.User;
import com.johannad.appStel.entity.Visitor;
import com.johannad.appStel.service.UserService;
import com.johannad.appStel.service.imp.UserImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/user", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class UserController {

    @Autowired
    private UserBusiness userBusiness;
    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllUser() throws Exception {
        Map<String,Object> res = new HashMap<>();
        List<UserDto> listUserDto=this.userBusiness.findAll();
        res.put("status","success");
        res.put("data",listUserDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createUser(@RequestBody UserDto newUser) {
        Map<String, Object> response = new HashMap<>();
        try {
            userBusiness.createUser(newUser);
            response.put("status", "success");
            response.put("data", newUser);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    /*@PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable int id, @RequestBody User updatedUser) {
        Map<String, Object> res = new HashMap<>();
        try {
            User existingUser = userImp.findById(id);
            if (existingUser == null) {
                res.put("status", "error");
                res.put("message", "User not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            existingUser.setUsuario(updatedUser.getUsuario());
            existingUser.setContrasena(updatedUser.getContrasena());


            userImp.update(existingUser);
            res.put("status", "success");
            res.put("data", existingUser);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/
}

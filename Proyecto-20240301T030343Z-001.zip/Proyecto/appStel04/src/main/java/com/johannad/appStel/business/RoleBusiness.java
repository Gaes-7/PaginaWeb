package com.johannad.appStel.business;

import com.johannad.appStel.dtos.RoleDto;
import com.johannad.appStel.entity.Role;
import com.johannad.appStel.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RoleBusiness {
@Autowired
    private RoleService roleService;
    private List<Role> roleList;

    private List<RoleDto> roleDtoList = new ArrayList<>();

    public List<RoleDto> findAll() throws Exception {
        this.roleList=this.roleService.findAll();
        this.roleList.stream().forEach(role -> {
            RoleDto roleDto=new RoleDto();
            roleDto.setId(role.getId());
            roleDto.setNombreRol(role.getNombreRol());
            this.roleDtoList.add(roleDto);
        });
        return this.roleDtoList;
    }
    public String createRole(RoleDto roleDto)throws Exception{
        Role role=new Role();
        role.setNombreRol(roleDto.getNombreRol());
        this.roleService.create(role);
        return "Registro exitoso";
    }
}

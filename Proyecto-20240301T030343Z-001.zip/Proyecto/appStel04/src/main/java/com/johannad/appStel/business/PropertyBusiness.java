package com.johannad.appStel.business;

import com.johannad.appStel.dtos.PropertyDto;
import com.johannad.appStel.entity.Property;
import com.johannad.appStel.service.PropertyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PropertyBusiness {

    @Autowired
    private PropertyService propertyService;

    private List<Property> propertyList;
    private List<PropertyDto> propertyDtoList = new ArrayList<>();

    public List<PropertyDto> findAll() throws Exception {
        this.propertyList = this.propertyService.findAll();
        this.propertyList.forEach(property -> {
            PropertyDto propertyDto = mapPropertyToDto(property);
            propertyDtoList.add(propertyDto);
        });
        return this.propertyDtoList;
    }

    public PropertyDto create(PropertyDto propertyDto) throws Exception {
        Property property = mapDtoToProperty(propertyDto);
        Property createdProperty = propertyService.create(property);
        return mapPropertyToDto(createdProperty);
    }

    private PropertyDto mapPropertyToDto(Property property) {
        PropertyDto propertyDto = new PropertyDto();
        propertyDto.setId(property.getId());
        propertyDto.setAndInmueble(property.getAndInmueble());
        propertyDto.setNumInmueble(property.getNumInmueble());
        return propertyDto;
    }

    private Property mapDtoToProperty(PropertyDto propertyDto) {
        Property property = new Property();
        property.setAndInmueble(propertyDto.getAndInmueble());
        property.setNumInmueble(propertyDto.getNumInmueble());
        return property;
    }
}

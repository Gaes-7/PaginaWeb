package com.johannad.appStel.business;

import com.johannad.appStel.dtos.PropertyDto;
import com.johannad.appStel.dtos.WalletStatusDto;
import com.johannad.appStel.dtos.WorkerDto;
import com.johannad.appStel.entity.Property;
import com.johannad.appStel.entity.WalletStatus;
import com.johannad.appStel.entity.Worker;
import com.johannad.appStel.service.PropertyService;
import com.johannad.appStel.service.WalletStatusService;
import com.johannad.appStel.service.WorkerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class WalletStatusBusiness {
    @Autowired
    private WalletStatusService walletStatusService;
    @Autowired
    private WorkerService workerService;
    @Autowired
    private PropertyService propertyService;
    private List<WalletStatus> walletStatusList;

    private List<WalletStatusDto> walletStatusDtoList = new ArrayList<>();

    public List<WalletStatusDto> findAll() throws Exception {
        this.walletStatusList=this.walletStatusService.findAll();
        this.walletStatusList.stream().forEach(walletStatus -> {
            WalletStatusDto walletStatusDto=new WalletStatusDto();
            walletStatusDto.setId(walletStatus.getId());

            Worker worker = walletStatus.getWorker();
            if (worker != null){
                WorkerDto workerDto = new WorkerDto();
                workerDto.setId(worker.getId());
                workerDto.setNomTrabajador(worker.getNomTrabajador());
                workerDto.setCcTrabajador(worker.getCcTrabajador());
                workerDto.setCelTrabajador(worker.getCelTrabajador());
                workerDto.setEmaTrabajador(worker.getEmaTrabajador());
                workerDto.setTpcoTrabajador(worker.getTpcoTrabajador());
                workerDto.setConTrabajador(worker.getConTrabajador());
                workerDto.setCargTrabajador(worker.getCargTrabajador());
                workerDto.setEmpTrabajador(worker.getEmpTrabajador());
                walletStatusDto.setWorker(workerDto);
            }
            Property property = walletStatus.getProperty();
            if (property != null){
                PropertyDto propertyDto = new PropertyDto();
                propertyDto.setId(property.getId());
                propertyDto.setAndInmueble(property.getAndInmueble());
                propertyDto.setNumInmueble(property.getNumInmueble());
                walletStatusDto.setProperty(propertyDto);
            }

            walletStatusDto.setDocestcartera(walletStatus.getDocestcartera());
            walletStatusDto.setEstcartera(walletStatus.getEstcartera());
            walletStatusDto.setTaccestcartera(walletStatus.getTaccestcartera());
            walletStatusDto.setNotiestcartera(walletStatus.getNotiestcartera());
            walletStatusDtoList.add(walletStatusDto);
        });
        return this.walletStatusDtoList;
    }
    public String createWalletStatus(WalletStatusDto walletStatusDto)throws Exception{
        WalletStatus walletStatus = new WalletStatus();
        walletStatus.setDocestcartera(walletStatusDto.getDocestcartera());
        walletStatus.setEstcartera(walletStatusDto.getEstcartera());
        walletStatus.setTaccestcartera(walletStatusDto.getTaccestcartera());
        walletStatus.setNotiestcartera(walletStatusDto.getNotiestcartera());
        this.walletStatusService.create(walletStatus);

        return "Registro exitoso";
    }
}

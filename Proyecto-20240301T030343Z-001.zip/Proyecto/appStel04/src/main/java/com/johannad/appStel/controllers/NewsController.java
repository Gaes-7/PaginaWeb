package com.johannad.appStel.controllers;

import com.johannad.appStel.business.NewsBusiness;
import com.johannad.appStel.dtos.CorrespondenceDto;
import com.johannad.appStel.dtos.NewsDto;
import com.johannad.appStel.entity.Fine;
import com.johannad.appStel.entity.News;
import com.johannad.appStel.service.imp.NewsImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/news", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")

public class NewsController {
    @Autowired
    private NewsBusiness newsBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllNews() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<NewsDto> listNewsDto = this.newsBusiness.findAll();
        res.put("status", "success");
        res.put("data", listNewsDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createNews(@RequestBody NewsDto newsDto) {
        Map<String, Object> res = new HashMap<>();
        try {
            NewsDto createdNewsDto = newsBusiness.create(newsDto);
            res.put("status", "success");
            res.put("data", createdNewsDto);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);


        }
    }
}




    /*@PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createNews(@RequestBody News news) {
        Map<String, Object> response = new HashMap<>();
        try {
            News newNews = newsBusiness.create(news);
            response.put("status", "success");
            response.put("data", newNews);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateNews(@PathVariable int id, @RequestBody News updatedNews) {
        Map<String, Object> res = new HashMap<>();
        try {
            News existingNews = newsImp.findById(id);
            if (existingNews == null) {
                res.put("status", "error");
                res.put("message", "News not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingNews.setRemNovedades(updatedNews.getRemNovedades());
            existingNews.setTipoNovedad(updatedNews.getTipoNovedad());
            existingNews.setAsuntoNovedades(updatedNews.getAsuntoNovedades());
            existingNews.setDescNovedades(updatedNews.getDescNovedades());
            existingNews.setDocNovedades(updatedNews.getDocNovedades());
            existingNews.setFecNovedades(updatedNews.getFecNovedades());
            existingNews.setResNovedades(updatedNews.getResNovedades());
            existingNews.setEstNovedades(updatedNews.getEstNovedades());

            newsImp.update(existingNews);
            res.put("status", "success");
            res.put("data", existingNews);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/


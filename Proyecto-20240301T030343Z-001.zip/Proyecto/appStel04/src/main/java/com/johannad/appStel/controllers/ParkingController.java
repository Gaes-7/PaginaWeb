package com.johannad.appStel.controllers;

import com.johannad.appStel.business.ParkingBusiness;
import com.johannad.appStel.dtos.ParkingDto;
import com.johannad.appStel.entity.News;
import com.johannad.appStel.entity.Parking;
import com.johannad.appStel.service.imp.ParkingImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/parking", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class ParkingController {
    @Autowired
    private ParkingBusiness parkingBusiness;
    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllParking() throws Exception {
        Map<String,Object> res = new HashMap<>();
        List<ParkingDto> listParkingDto=this.parkingBusiness.findAll();
        res.put("status","success");
        res.put("data",listParkingDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createParking(@RequestBody ParkingDto newsDto) {
        Map<String, Object> res = new HashMap<>();
        try {
            ParkingDto createdNewsDto = parkingBusiness.create(newsDto);
            res.put("status", "success");
            res.put("data", createdNewsDto);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*@PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createParking(@RequestBody Parking parking) {
        Map<String, Object> response = new HashMap<>();
        try {
            Parking newParking = parkingBusiness.create(parking);
            response.put("status", "success");
            response.put("data", newParking);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateParking(@PathVariable int id, @RequestBody Parking updatedParking) {
        Map<String, Object> res = new HashMap<>();
        try {
            Parking existingParking = parkingBusiness.findById(id);
            if (existingParking == null) {
                res.put("status", "error");
                res.put("message", "Parking not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingParking.setTipoParqueadero(updatedParking.getTipoParqueadero());
            existingParking.setEstadoParqueadero(updatedParking.getEstadoParqueadero());
            existingParking.setFecParqueadero(updatedParking.getFecParqueadero());
            existingParking.setDvteParqueadero(updatedParking.getDvteParqueadero());
            existingParking.setCupParqueadero(updatedParking.getCupParqueadero());
            existingParking.setHoraSalida(updatedParking.getHoraSalida());
            existingParking.setTarParqueadero(updatedParking.getTarParqueadero());

            parkingImp.update(existingParking);
            res.put("status", "success");
            res.put("data", existingParking);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/
}

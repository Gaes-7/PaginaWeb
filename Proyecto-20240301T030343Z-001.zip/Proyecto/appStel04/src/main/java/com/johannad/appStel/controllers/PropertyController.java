package com.johannad.appStel.controllers;


import com.johannad.appStel.business.PropertyBusiness;
import com.johannad.appStel.dtos.PropertyDto;
import com.johannad.appStel.entity.Parking;
import com.johannad.appStel.entity.Property;
import com.johannad.appStel.service.imp.PropertyImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/property", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class PropertyController {
    @Autowired
    private PropertyBusiness propertyBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllProperty() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<PropertyDto> listPropertyDto = this.propertyBusiness.findAll();
        res.put("status", "success");
        res.put("data", listPropertyDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createProperty(@RequestBody PropertyDto propertyDto) {
        Map<String, Object> res = new HashMap<>();
        try {
            PropertyDto createdNewsDto = propertyBusiness.create(propertyDto);
            res.put("status", "success");
            res.put("data", createdNewsDto);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*@PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createProperty(@RequestBody Property property) {
        Map<String, Object> response = new HashMap<>();
        try {
            Property newProperty = propertyImp.create(property);
            response.put("status", "success");
            response.put("data", newProperty);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateProperty(@PathVariable int id, @RequestBody Property updatedProperty) {
        Map<String, Object> res = new HashMap<>();
        try {
            Property existingProperty = propertyImp.findById(id);
            if (existingProperty == null) {
                res.put("status", "error");
                res.put("message", "Property not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingProperty.setAndInmueble(updatedProperty.getAndInmueble());
            existingProperty.setNumInmueble(updatedProperty.getNumInmueble());


            propertyImp.update(existingProperty);
            res.put("status", "success");
            res.put("data", existingProperty);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/
}

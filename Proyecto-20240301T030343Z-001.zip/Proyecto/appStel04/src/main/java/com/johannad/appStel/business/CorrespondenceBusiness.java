package com.johannad.appStel.business;

import com.johannad.appStel.dtos.CorrespondenceDto;
import com.johannad.appStel.dtos.WorkerDto;
import com.johannad.appStel.entity.Correspondence;
import com.johannad.appStel.entity.Worker;
import com.johannad.appStel.service.CorrespondenceService;
import com.johannad.appStel.service.WorkerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CorrespondenceBusiness {
    @Autowired
    private CorrespondenceService correspondenceService;

    @Autowired
    private WorkerService workerService;

    private List<Correspondence> correspondenceList;
    private List<CorrespondenceDto> correspondenceDtoList = new ArrayList<>();

    public List<CorrespondenceDto> findAll() throws Exception {
        this.correspondenceList = this.correspondenceService.findAll();
        this.correspondenceList.forEach(correspondence -> {
            CorrespondenceDto correspondenceDto = mapCorrespondenceToDto(correspondence);
            correspondenceDtoList.add(correspondenceDto);
        });
        return this.correspondenceDtoList;
    }

    public CorrespondenceDto create(CorrespondenceDto correspondenceDto) throws Exception {
        Correspondence correspondence = mapDtoToCorrespondence(correspondenceDto);
        Correspondence createdCorrespondence = correspondenceService.create(correspondence);
        return mapCorrespondenceToDto(createdCorrespondence);
    }

    private CorrespondenceDto mapCorrespondenceToDto(Correspondence correspondence) {
        CorrespondenceDto correspondenceDto = new CorrespondenceDto();
        correspondenceDto.setId(correspondence.getId());

        WorkerDto workerDto = new WorkerDto();
        Worker worker = correspondence.getWorker();
        if (worker != null) {
            workerDto.setId(worker.getId());
            // Mapear otros campos de WorkerDto según sea necesario
            correspondenceDto.setWorker(workerDto);
        }

        correspondenceDto.setTipoCorrespondencia(correspondence.getTipoCorrespondencia());
        correspondenceDto.setFrecCorrespondencia(correspondence.getFrecCorrespondencia());
        correspondenceDto.setEstCorrespondencia(correspondence.getEstCorrespondencia());
        correspondenceDto.setFentrCorrespondencia(correspondence.getFentrCorrespondencia());

        return correspondenceDto;
    }

    private Correspondence mapDtoToCorrespondence(CorrespondenceDto correspondenceDto) {
        Correspondence correspondence = new Correspondence();
        correspondence.setTipoCorrespondencia(correspondenceDto.getTipoCorrespondencia());
        correspondence.setFrecCorrespondencia(correspondenceDto.getFrecCorrespondencia());
        correspondence.setEstCorrespondencia(correspondenceDto.getEstCorrespondencia());
        correspondence.setFentrCorrespondencia(correspondenceDto.getFentrCorrespondencia());

        WorkerDto workerDto = correspondenceDto.getWorker();
        if (workerDto != null) {
            Worker worker = new Worker();
            worker.setId(workerDto.getId());
            // Mapear otros campos de Worker según sea necesario
            correspondence.setWorker(worker);
        }

        return correspondence;
    }
}

package com.johannad.appStel.controllers;

import com.johannad.appStel.business.FineBusiness;
import com.johannad.appStel.dtos.CorrespondenceDto;
import com.johannad.appStel.dtos.FineDto;
import com.johannad.appStel.entity.Correspondence;
import com.johannad.appStel.entity.Fine;
import com.johannad.appStel.service.imp.FineImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/fine", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class FineController {

    @Autowired
    private FineBusiness fineBusiness;
    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllFine() throws Exception {
        Map<String,Object> res = new HashMap<>();
        List<FineDto> listFineDto = this.fineBusiness.findAll();
        res.put("status","success");
        res.put("data",listFineDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createFine(@RequestBody FineDto fineDto) {
        Map<String, Object> res = new HashMap<>();
        try {
            FineDto createdFineDto = fineBusiness.create(fineDto);
            res.put("status", "success");
            res.put("data", createdFineDto);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    /*@PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createFine(@RequestBody Fine fine) {
        Map<String, Object> response = new HashMap<>();
        try {
            Fine newFine = fineBusiness.create(fine);
            response.put("status", "success");
            response.put("data", newFine);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateFine(@PathVariable int id, @RequestBody Fine updatedFine) {
        Map<String, Object> res = new HashMap<>();
        try {
            Fine existingFine = fineBusiness.findById(id);
            if (existingFine == null) {
                res.put("status", "error");
                res.put("message", "Fine not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingFine.setTipoMulta(updatedFine.getTipoMulta());
            existingFine.setFecMulta(updatedFine.getFecMulta());
            existingFine.setEvidMulta(updatedFine.getEvidMulta());
            existingFine.setValMulta(updatedFine.getValMulta());
            existingFine.setFpagMulta(updatedFine.getFpagMulta());

            fineImp.update(existingFine);
            res.put("status", "success");
            res.put("data", existingFine);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/
}

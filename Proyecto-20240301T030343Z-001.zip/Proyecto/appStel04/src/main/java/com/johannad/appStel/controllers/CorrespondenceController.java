package com.johannad.appStel.controllers;

import com.johannad.appStel.business.CorrespondenceBusiness;
import com.johannad.appStel.dtos.AdminDocsDto;
import com.johannad.appStel.dtos.CorrespondenceDto;
import com.johannad.appStel.entity.AdminDocs;
import com.johannad.appStel.entity.Correspondence;
import com.johannad.appStel.service.imp.CorrespondenceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/correspondence", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")

public class CorrespondenceController {

    @Autowired
    private CorrespondenceBusiness correspondenceBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllCorrespondence() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<CorrespondenceDto> listCorrespondenceDto = this.correspondenceBusiness.findAll();
        res.put("status", "success");
        res.put("data", listCorrespondenceDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createCorrespondence(@RequestBody CorrespondenceDto correspondenceDto) {
        Map<String, Object> res = new HashMap<>();
        try {
            CorrespondenceDto createdCorrespondenceDto = correspondenceBusiness.create(correspondenceDto);
            res.put("status", "success");
            res.put("data", createdCorrespondenceDto);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
    /*@PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createCorrespondence(@RequestBody Correspondence correspondence) {
        Map<String, Object> response = new HashMap<>();
        try {
            Correspondence newCorrespondence = correspondenceBusiness.create(correspondence);
            response.put("status", "success");
            response.put("data", newCorrespondence);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateCorrespondence(@PathVariable int id, @RequestBody Correspondence updatedCorrespondence) {
        Map<String, Object> res = new HashMap<>();
        try {
            Correspondence existingCorrespondence = correspondenceBusiness.findById(id);
            if (existingCorrespondence == null) {
                res.put("status", "error");
                res.put("message", "Correspondence not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingCorrespondence.setTipoCorrespondencia(updatedCorrespondence.getTipoCorrespondencia());
            existingCorrespondence.setFrecCorrespondencia(updatedCorrespondence.getFrecCorrespondencia());
            existingCorrespondence.setEstCorrespondencia(updatedCorrespondence.getEstCorrespondencia());
            existingCorrespondence.setFentrCorrespondencia(updatedCorrespondence.getFentrCorrespondencia());

            correspondenceBusiness.update(existingCorrespondence);
            res.put("status", "success");
            res.put("data", existingCorrespondence);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
                res.put("status", "error");
                res.put("message", e.getMessage());
                return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/


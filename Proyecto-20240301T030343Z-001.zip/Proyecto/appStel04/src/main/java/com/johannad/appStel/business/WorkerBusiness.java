package com.johannad.appStel.business;

import com.johannad.appStel.dtos.*;
import com.johannad.appStel.entity.*;
import com.johannad.appStel.service.RoleService;
import com.johannad.appStel.service.VisitorService;
import com.johannad.appStel.service.WalletStatusService;
import com.johannad.appStel.service.WorkerService;
import com.sun.jdi.PrimitiveValue;
import jakarta.persistence.metamodel.SingularAttribute;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.AbstractPersistable;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Component

public class WorkerBusiness {

    @Autowired
    private WorkerService workerService;
    @Autowired
    private RoleService roleService;

    private List<Worker> workerList;
    private List<WorkerDto> workerDtoList = new ArrayList<>();

    public List<WorkerDto> findAll() throws Exception {
        this.workerList = this.workerService.findAll();
        this.workerList.stream().forEach(worker -> {
            WorkerDto workerDto = new WorkerDto();
            workerDto.setId(worker.getId());

            Role role = worker.getRole();
            if (role != null){
                RoleDto roleDto = new RoleDto();
                roleDto.setId(role.getId());
                roleDto.setNombreRol(role.getNombreRol());
                workerDto.setRole(roleDto);
            }
            workerDto.setNomTrabajador(worker.getNomTrabajador());
            workerDto.setCcTrabajador(worker.getCcTrabajador());
            workerDto.setCelTrabajador(worker.getCelTrabajador());
            workerDto.setEmaTrabajador(worker.getEmaTrabajador());
            workerDto.setTpcoTrabajador(worker.getTpcoTrabajador());
            workerDto.setConTrabajador(worker.getConTrabajador());
            workerDto.setCargTrabajador(worker.getCargTrabajador());
            workerDto.setEmpTrabajador(worker.getEmpTrabajador());
            workerDtoList.add(workerDto);
        });
        return this.workerDtoList;
    }
    public Worker findById(int id) {return this.workerService.findById(id);}
    public void createWorker(WorkerDto workerDto) throws Exception {
        Worker worker = new Worker();

        if (workerDto.getRole() != null) {
            Role role = roleService.findById(workerDto.getRole().getId());
            if (role != null) {
                worker.setRole(role);
            } else {
                // Manejar el caso en que no se encuentra el Role
                throw new Exception("Role no encontrado para el id: " + workerDto.getRole().getId());
            }
        }
        worker.setNomTrabajador(workerDto.getNomTrabajador());
        worker.setCcTrabajador(workerDto.getCcTrabajador());
        worker.setCelTrabajador(workerDto.getCelTrabajador());
        worker.setEmaTrabajador(workerDto.getEmaTrabajador());
        worker.setTpcoTrabajador(workerDto.getTpcoTrabajador());
        worker.setConTrabajador(workerDto.getConTrabajador());
        worker.setCargTrabajador(workerDto.getCargTrabajador());
        worker.setEmpTrabajador(workerDto.getEmpTrabajador());
        List<Worker> workerList = this.workerService.findAll();
        //workerDtoList.add(workerDto);






    }
}

package com.johannad.appStel.controllers;


import com.johannad.appStel.business.RoleBusiness;
import com.johannad.appStel.dtos.RoleDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/role", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class RoleController {
    @Autowired
    private RoleBusiness roleBusiness;
    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllRole() throws Exception {
        Map<String,Object> res = new HashMap<>();
        List<RoleDto> listRoleDto=this.roleBusiness.findAll();
        res.put("status","success");
        res.put("data",listRoleDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createRole(@RequestBody RoleDto newRole) {
        Map<String, Object> response = new HashMap<>();
        try {
            roleBusiness.createRole(newRole);
            response.put("status", "success");
            response.put("data", newRole);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    /*@PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateRole(@PathVariable int id, @RequestBody Role updatedRole) {
        Map<String, Object> res = new HashMap<>();
        try {
            Role existingRole = roleImp.findById(id);
            if (existingRole == null) {
                res.put("status", "error");
                res.put("message", "User not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            existingRole.setNombreRol(updatedRole.getNombreRol());

            roleImp.update(existingRole);
            res.put("status", "success");
            res.put("data", existingRole);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/
}

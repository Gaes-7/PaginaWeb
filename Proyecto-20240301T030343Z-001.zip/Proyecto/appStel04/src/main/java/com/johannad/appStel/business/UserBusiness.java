package com.johannad.appStel.business;

import com.johannad.appStel.dtos.RoleDto;
import com.johannad.appStel.dtos.UserDto;
import com.johannad.appStel.entity.Role;
import com.johannad.appStel.entity.User;
import com.johannad.appStel.service.RoleService;
import com.johannad.appStel.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserBusiness {
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    private List<User> userList;
    private List<UserDto> userDtoList = new ArrayList<>();
    public List<UserDto> findAll() throws Exception {
        this.userList=this.userService.findAll();
        this.userList.stream().forEach(user -> {
            UserDto userDto = new UserDto();
            userDto.setId(user.getId());

            Role role = user.getRole();
            if (role != null){
                RoleDto roleDto = new RoleDto();
                roleDto.setId(role.getId());
                roleDto.setNombreRol(role.getNombreRol());
                userDto.setRole(roleDto);
            }
            userDto.setUsuario(user.getUsuario());
            userDto.setContrasena(user.getContrasena());
            userDtoList.add(userDto);
        });
        return this.userDtoList;
    }
    public String createUser(UserDto userDto)throws Exception{
        User user=new User();
        user.setUsuario(userDto.getUsuario());
        user.setContrasena(userDto.getContrasena());
        this.userService.create(user);

        return "Registro exitoso";
    }

}

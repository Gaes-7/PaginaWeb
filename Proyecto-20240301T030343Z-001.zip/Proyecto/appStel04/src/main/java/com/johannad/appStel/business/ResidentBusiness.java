package com.johannad.appStel.business;

import com.johannad.appStel.dtos.ParkingDto;
import com.johannad.appStel.dtos.ResidentDto;
import com.johannad.appStel.dtos.RoleDto;
import com.johannad.appStel.entity.Parking;
import com.johannad.appStel.entity.Resident;
import com.johannad.appStel.entity.Role;
import com.johannad.appStel.service.ParkingService;
import com.johannad.appStel.service.ResidentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ResidentBusiness {
@Autowired
    private ResidentService residentService;
@Autowired
    private  ResidentService roleService;
@Autowired
    private ParkingService parkingService;
    private List<Resident> residentList;
    private List<ResidentDto> residentDtoList = new ArrayList<>();

    public List<ResidentDto> findAll() throws Exception {
        this.residentList=this.residentService.findAll();
        this.residentList.stream().forEach(resident -> {
            ResidentDto residentDto=new ResidentDto();
            residentDto.setId(resident.getId());

            Role role = resident.getRole();
            if (role != null){
                RoleDto roleDto = new RoleDto();
                roleDto.setId(role.getId());
                roleDto.setNombreRol(role.getNombreRol());
                residentDto.setRole(roleDto);
            }
            Parking parking = resident.getParking();
            if (parking != null){
                ParkingDto parkingDto = new ParkingDto();
                parkingDto.setId(parking.getId());
                parkingDto.setTipoParqueadero(parking.getTipoParqueadero());
                parkingDto.setEstadoParqueadero(parking.getEstadoParqueadero());
                parkingDto.setFecParqueadero(parking.getFecParqueadero());
                parkingDto.setDvteParqueadero(parking.getDvteParqueadero());
                parkingDto.setCupParqueadero(parking.getCupParqueadero());
                parkingDto.setHoraSalida(parking.getHoraSalida());
                parkingDto.setTarParqueadero(parking.getTarParqueadero());
                residentDto.setParking(parkingDto);
            }

            residentDto.setNomResidente(resident.getNomResidente());
            residentDto.setCedResidente(resident.getCedResidente());
            residentDto.setEmaResidente(resident.getEmaResidente());
            residentDto.setCelResidente(resident.getCelResidente());
            residentDto.setNumIntegrantes(resident.getNumIntegrantes());
            this.residentDtoList.add(residentDto);
        });
        return this.residentDtoList;
    }
    public String createResident(ResidentDto residentDto)throws Exception{
        Resident resident=new Resident();
        residentDto.setNomResidente(resident.getNomResidente());
        residentDto.setCedResidente(resident.getCedResidente());
        residentDto.setEmaResidente(resident.getEmaResidente());
        residentDto.setCelResidente(resident.getCelResidente());
        residentDto.setNumIntegrantes(resident.getNumIntegrantes());
        this.residentService.create(resident);
        return "Registro exitoso";
    }
}

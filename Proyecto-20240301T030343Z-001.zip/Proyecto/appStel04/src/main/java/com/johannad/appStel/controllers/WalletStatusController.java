package com.johannad.appStel.controllers;


import com.johannad.appStel.business.WalletStatusBusiness;
import com.johannad.appStel.dtos.WalletStatusDto;
import com.johannad.appStel.dtos.WorkerDto;
import com.johannad.appStel.entity.Visitor;
import com.johannad.appStel.entity.WalletStatus;
import com.johannad.appStel.entity.Worker;
import com.johannad.appStel.service.imp.WalletStatusImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/walletStatus", method = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST})
@CrossOrigin("*")
public class WalletStatusController {
    @Autowired
    private WalletStatusBusiness walletStatusBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllWalletStatus() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<WalletStatusDto> listWalletStatusDto = this.walletStatusBusiness.findAll();
        res.put("status", "success");
        res.put("data", listWalletStatusDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createWalletStatus(@RequestBody WalletStatusDto newWalletStatus) {
        Map<String, Object> response = new HashMap<>();
        try {
            walletStatusBusiness.createWalletStatus(newWalletStatus);
            response.put("status", "success");
            response.put("message", newWalletStatus);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /*@PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateWalletStatus(@PathVariable int id, @RequestBody WalletStatus updatedWalletStatus) {
        Map<String, Object> res = new HashMap<>();
        try {
            WalletStatus existingWalletStatus = walletStatusImp.findById(id);
            if (existingWalletStatus == null) {
                res.put("status", "error");
                res.put("message", "User not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingWalletStatus.setDocestcartera(updatedWalletStatus.getDocestcartera());
            existingWalletStatus.setEstcartera(updatedWalletStatus.getEstcartera());
            existingWalletStatus.setTaccestcartera(updatedWalletStatus.getTaccestcartera());
            existingWalletStatus.setNotiestcartera(updatedWalletStatus.getNotiestcartera());

            walletStatusImp.update(existingWalletStatus);
            res.put("status", "success");
            res.put("data", existingWalletStatus);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/
}


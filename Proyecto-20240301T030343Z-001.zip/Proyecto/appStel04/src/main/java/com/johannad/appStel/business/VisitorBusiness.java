package com.johannad.appStel.business;

import com.johannad.appStel.dtos.ParkingDto;
import com.johannad.appStel.dtos.PropertyDto;
import com.johannad.appStel.dtos.VisitorDto;
import com.johannad.appStel.dtos.WorkerDto;
import com.johannad.appStel.entity.Parking;
import com.johannad.appStel.entity.Property;
import com.johannad.appStel.entity.Visitor;
import com.johannad.appStel.entity.Worker;
import com.johannad.appStel.service.ParkingService;
import com.johannad.appStel.service.PropertyService;
import com.johannad.appStel.service.VisitorService;
import com.johannad.appStel.service.WorkerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class VisitorBusiness {
    @Autowired
    private VisitorService visitorService;
    @Autowired
    private WorkerService workerService;
    @Autowired
    private PropertyService propertyService;
    @Autowired
    private ParkingService parkingService;

    private List<Visitor> visitorList;
    private  List<VisitorDto> visitorDtoList = new ArrayList<>();

    public List<VisitorDto> findAll() throws Exception {
        this.visitorList =this.visitorService.findAll();
        this.visitorList.stream().forEach(visitor -> {
            VisitorDto visitorDto=new VisitorDto();
            visitorDto.setId(visitor.getId());

            Worker worker = visitor.getWorker();
            if (worker != null){
                WorkerDto workerDto = new WorkerDto();
                workerDto.setId(worker.getId());
                workerDto.setNomTrabajador(worker.getNomTrabajador());
                workerDto.setCcTrabajador(worker.getCcTrabajador());
                workerDto.setCelTrabajador(worker.getCelTrabajador());
                workerDto.setEmaTrabajador(worker.getEmaTrabajador());
                workerDto.setTpcoTrabajador(worker.getTpcoTrabajador());
                workerDto.setConTrabajador(worker.getConTrabajador());
                workerDto.setCargTrabajador(worker.getCargTrabajador());
                workerDto.setEmpTrabajador(worker.getEmpTrabajador());
                visitorDto.setWorker(workerDto);
            }
            Property property = visitor.getProperty();
            if (property != null){
                PropertyDto propertyDto = new PropertyDto();
                propertyDto.setId(property.getId());
                propertyDto.setAndInmueble(property.getAndInmueble());
                propertyDto.setNumInmueble(property.getNumInmueble());
                visitorDto.setProperty(propertyDto);
            }
            Parking parking = visitor.getParking();
            if (parking != null){
                ParkingDto parkingDto = new ParkingDto();
                parkingDto.setId(parking.getId());
                parkingDto.setTipoParqueadero(parking.getTipoParqueadero());
                parkingDto.setEstadoParqueadero(parking.getEstadoParqueadero());
                parkingDto.setFecParqueadero(parking.getFecParqueadero());
                parkingDto.setDvteParqueadero(parking.getDvteParqueadero());
                parkingDto.setCupParqueadero(parking.getCupParqueadero());
                parkingDto.setHoraSalida(parking.getHoraSalida());
                parkingDto.setTarParqueadero(parking.getTarParqueadero());
                visitorDto.setParking(parkingDto);

            }
            visitorDto.setNomVisitante(visitor.getNomVisitante());
            visitorDto.setCedVisitante(visitor.getCedVisitante());
            visitorDto.setNomResidente(visitor.getNomResidente());
            visitorDto.setCarVisitante(visitor.isCarVisitante());
            visitorDto.setIngrVisitante(visitor.isIngrVisitante());
            visitorDto.setFecVisitante(visitor.getFecVisitante());
            visitorDtoList.add(visitorDto);
        });
        return this.visitorDtoList;
    }
    public String createVisitor(VisitorDto visitorDto)throws Exception{
        Visitor visitor=new Visitor();
        visitor.setId(visitorDto.getId());
        visitor.setNomVisitante(visitorDto.getNomVisitante());
        visitor.setCedVisitante(visitorDto.getCedVisitante());
        visitor.setNomResidente(visitorDto.getNomResidente());
        visitor.setCarVisitante(visitorDto.isCarVisitante());
        visitor.setIngrVisitante(visitorDto.isIngrVisitante());
        visitor.setFecVisitante(visitorDto.getFecVisitante());
        this.visitorService.create(visitor);
        return "Registro exitoso";
    }

}

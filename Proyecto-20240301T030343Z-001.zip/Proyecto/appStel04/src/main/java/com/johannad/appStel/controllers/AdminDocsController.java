package com.johannad.appStel.controllers;

import com.johannad.appStel.business.AdminDocsBusiness;
import com.johannad.appStel.dtos.AdminDocsDto;
import com.johannad.appStel.entity.AdminDocs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/adminDocs", method = {RequestMethod.GET, RequestMethod.POST})
@CrossOrigin("*")
public class AdminDocsController {

    @Autowired
    private AdminDocsBusiness adminDocsBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllAdminDocs() throws Exception {
        Map<String, Object> res = new HashMap<>();
        List<AdminDocsDto> listAdmindocsDto = this.adminDocsBusiness.findAll();
        res.put("status", "success");
        res.put("data", listAdmindocsDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createAdminDocs(@RequestBody AdminDocsDto adminDocsDto) {
        Map<String, Object> res = new HashMap<>();
        try {
            AdminDocsDto createdAdminDocsDto = adminDocsBusiness.create(adminDocsDto);
            res.put("status", "success");
            res.put("data", createdAdminDocsDto);
            return new ResponseEntity<>(res, HttpStatus.CREATED);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateAdminDocs(@PathVariable int id, @RequestBody AdminDocsDto updatedAdminDocsDto) {
        Map<String, Object> res = new HashMap<>();
        try {
            adminDocsBusiness.update(updatedAdminDocsDto, id);
            res.put("status", "success");
            res.put("data", updatedAdminDocsDto);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}





    /*@PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createAdminDocs(@RequestBody AdminDocs adminDocs) {
        Map<String, Object> response = new HashMap<>();
        try {
            AdminDocs newAdminDocs = adminDocsBusiness.createAdminDocs(adminDocs);
            response.put("status", "success");
            response.put("data", newAdminDocs);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateAdminDocs(@PathVariable int id, @RequestBody AdminDocs updatedAdminDocs) {
        Map<String, Object> res = new HashMap<>();
        try {
            AdminDocs existingAdminDocs = adminDocsBusiness.findById(id);
            if (existingAdminDocs == null) {
                res.put("status", "error");
                res.put("message", "User not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }

            existingAdminDocs.setClassDocsAdmin(updatedAdminDocs.getClassDocsAdmin());
            existingAdminDocs.setPetiDocsAdmin(updatedAdminDocs.getPetiDocsAdmin());

            adminDocsBusiness.update(existingAdminDocs);
            res.put("status", "success");
            res.put("data", existingAdminDocs);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }*/










package com.johannad.appStel.controllers;
import com.johannad.appStel.business.ResidentBusiness;
import com.johannad.appStel.dtos.ResidentDto;
import com.johannad.appStel.entity.Property;
import com.johannad.appStel.entity.Role;
import com.johannad.appStel.service.imp.ResidentImp;
import com.johannad.appStel.entity.Resident;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/resident", method = {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST} )
@CrossOrigin("*")
public class ResidentController {
    @Autowired
    private ResidentBusiness residentBusiness;
    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllResident() throws Exception {
        Map<String,Object> res = new HashMap<>();
        List<ResidentDto> listResidentDto=this.residentBusiness.findAll();
        res.put("status","success");
        res.put("data",listResidentDto);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }
    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createResident(@RequestBody ResidentDto newResident) {
        Map<String, Object> response = new HashMap<>();
        try {
            residentBusiness.createResident(newResident);
            response.put("status", "success");
            response.put("data", newResident);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    /*@PutMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateResident(@PathVariable int id, @RequestBody Resident updatedResident) {
        Map<String, Object> res = new HashMap<>();
        try {
            Resident existingResident = residentImp.findById(id);
            if (existingResident == null) {
                res.put("status", "error");
                res.put("message", "User not found");
                return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
            }
            existingResident.setNomResidente(updatedResident.getNomResidente());
            existingResident.setCedResidente(updatedResident.getCedResidente());
            existingResident.setEmaResidente(updatedResident.getEmaResidente());
            existingResident.setCelResidente(updatedResident.getCelResidente());
            existingResident.setNumIntegrantes(updatedResident.getNumIntegrantes());

            residentImp.update(existingResident);
            res.put("status", "success");
            res.put("data", existingResident);
            return new ResponseEntity<>(res, HttpStatus.OK);
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }*/

}

package com.example.demo.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name="cargo")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Position {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idCargo;

    @Column(name = "NomCargo", length = 25)
    private String NomCargo;

    @ManyToMany(mappedBy = "idEmpleado", fetch = FetchType.LAZY)
    private List<Employees> employeesList;


}

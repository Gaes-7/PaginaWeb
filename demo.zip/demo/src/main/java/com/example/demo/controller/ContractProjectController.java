/*package com.example.demo.controller;

import com.example.demo.DTO.ContractProjectDTO;
import com.example.demo.Entity.ContractProyct;
import com.example.demo.business.ContractProjectBusiness;
import com.example.demo.service.imp.ContractProyctService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

    @RestController
    @RequestMapping(path = "/api/ContractProject",method = {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST})
    @CrossOrigin("*")
    public class ContractProjectController {

        @Autowired
        ContractProjectBusiness contractProjectBusiness;
        @Autowired
        private ContractProyctService contractProyctService;



        @GetMapping("/all")
        public ResponseEntity<Map<String,Object>> findAllUser() {
            Map<String, Object> response = new HashMap<>();
            List<ContractProyct> Userlist = ContractProyctService.findAll();
            response.put( "status", "success");
            response.put("data", Userlist);

            return new ResponseEntity<>(response, HttpStatus.OK);

        }


        @PostMapping ("/create")
        public ResponseEntity<Map<String,Object>>createContractProject(@RequestBody Map<String,Object>request) {
            Map<String, Object> response = new HashMap<>();
            try {
                this.contractProjectBusiness.create((ContractProjectDTO) request);

                response.put("status", "Succes");
                response.put("msm", "Actualizacion Exitosa");
            } catch (Exception e) {
                response.put("status", "Failed");
                response.put("msm", "Fallo Exitoso por" + e.getMessage());
            }
            return new ResponseEntity<>(response, HttpStatus.OK);

        }




        @PostMapping ("/update")
        public ResponseEntity<Map<String,Object>>updateUser(@RequestBody Map<String,Object>request){
            Map<String,Object> response=new HashMap<>();
            try{
                ContractProyct contractProyct = new ContractProyct();
                contractProyct.setFechaInicio(Date.valueOf(request.get("FechaIncio").toString()));
                contractProyct.setFechaFin(Date.valueOf(request.get("FechaFin").toString()));
                this.ContractProjectService.create(user);
                response.put("status", "Succes");
                response.put("msm","Actualizacion Exitosa");
            }catch (Exception e){
                response.put("status","Failed");
                response.put("msm","Fallo Exitoso por"+e.getMessage());
            }
            return new ResponseEntity<>(response,HttpStatus.OK);

        }

    }
}
*/
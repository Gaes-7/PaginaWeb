package com.example.demo.business;

import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.User;
import com.example.demo.service.imp.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UserBusiness {
    @Autowired
    private UserService userService;

    private final List<UserDTO> userDTOList = new ArrayList<>();

    public List<UserDTO> findAll() {
        List<User> userList = this.userService.findAll();
        userList.forEach(user -> {
            UserDTO userDTO = new UserDTO();
            userDTO.setId((int) user.getIdUsuario());
            userDTO.setUsuario(String.valueOf(user.getUsuario()));
            userDTO.setContrasena(String.valueOf(user.getContrasena()));
            this.userDTOList.add(userDTO);
        });
        return this.userDTOList;
    }

    public String create(UserDTO userDTO) {
        try {
            User user = new User();
            userDTO.setUsuario(String.valueOf(user.getUsuario()));
            user.setContrasena(String.valueOf(userDTO.getContrasena()));
            userService.create(user);
            return "Usuario creado correctamente.";
        } catch (Exception e) {
            return "Error al crear usuario: " + e.getMessage();
        }
    }

    public String update(UserDTO userDTO) {
        User user = userService.findById(userDTO.getId());
        if (user != null) {
            userDTO.setUsuario(String.valueOf(user.getUsuario()));
            user.setContrasena(String.valueOf(userDTO.getContrasena()));
            userService.update(user);
            return "Usuario actualizado correctamente.";
        } else {
            return "El usuario no existe.";
        }
    }
}

package com.example.demo.controller;

import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.User;
import com.example.demo.business.UserBusiness;
import com.example.demo.service.imp.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



@RestController
@RequestMapping(path = "/api/User",method = {RequestMethod.GET,RequestMethod.PUT,RequestMethod.POST})
@CrossOrigin("*")
public class UserController {

    @Autowired
    UserBusiness userBusiness;
    @Autowired
    private  UserService userService;



    @GetMapping("/all")
    public ResponseEntity<Map<String,Object>> findAllUser() {
        Map<String, Object> response = new HashMap<>();
        List<User> Userlist = userService.findAll();
        response.put( "status", "success");
        response.put("data", Userlist);

        return new ResponseEntity<>(response, HttpStatus.OK);

    }


    @PostMapping ("/create")
    public ResponseEntity<Map<String,Object>>createUser(@RequestBody Map<String,Object>request) {
        Map<String, Object> response = new HashMap<>();

        try {
            this.userBusiness.create((UserDTO) request);

            response.put("status", "Succes");
            response.put("msm", "Actualizacion Exitosa");
        } catch (Exception e) {
            response.put("status", "Failed");
            response.put("msm", "Fallo Exitoso por" + e.getMessage());
        }
        return new ResponseEntity<>(response, HttpStatus.OK);

    }




    @PostMapping ("/update")
    public ResponseEntity<Map<String,Object>>updateUser(@RequestBody Map<String,Object>request){
        Map<String,Object> response=new HashMap<>();
        try{
            User user=new User();
            user.setUsuario(request.get("Usuario").toString());
            user.setContrasena(String.valueOf(request.get("password").toString()));
            this.userService.create(user);
            response.put("status", "Succes");
            response.put("msm","Actualizacion Exitosa");
        }catch (Exception e){
            response.put("status","Failed");
            response.put("msm","Fallo Exitoso por"+e.getMessage());
        }
        return new ResponseEntity<>(response,HttpStatus.OK);

    }

}

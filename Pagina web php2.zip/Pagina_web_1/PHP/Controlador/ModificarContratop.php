<?php

if (!empty($_POST["btnañadir"])) {
    if (!empty($_POST["fechaI"]) and !empty($_POST["fechaF"]) and !empty($_POST["valor"]) and !empty($_POST["clausula"])) {
        
        $id=$_POST["id"];
        $fechaI=$_POST["fechaI"];
        $FechaF=$_POST["fechaF"];
        $valor=$_POST["valor"];
        $clausula=$_POST["clausula"];


        $sql=$conexion->query(" update contratoproyecto set FechaInicio='$fechaI', FechaFin='$FechaF', Valor=$valor, Clausula='$clausula' where idContratoProyecto=$id ");
        if ($sql == 1){
            header("location:contrato.php");
        } else {
            echo "<div class='alert alert-danger'> Error al modificar los campos </div>";
        }
    }else 
        echo "<div class='alert alert-warning'> Complete todo los campos </div>";
}

?>
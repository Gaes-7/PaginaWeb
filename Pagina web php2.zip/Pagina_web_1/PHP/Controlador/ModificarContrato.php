<?php

if (!empty($_POST["btnañadir"])) {
    if (!empty($_POST["contrato"]) and !empty($_POST["fechaI"]) and !empty($_POST["fechaF"]) and !empty($_POST["salario"]) and !empty($_POST["banco"])) {
        
        $id=$_POST["id"];
        $contrato=$_POST["contrato"];
        $fechaI=$_POST["fechaI"];
        $FechaF=$_POST["fechaF"];
        $salario=$_POST["salario"];
        $banco=$_POST["banco"];


        $sql=$conexion->query(" update contratoemp set TipoContrato='$contrato', FechaInicio='$fechaI', FechaFin='$FechaF', Salario='$salario', Banco='$banco' where idContratoEmp=$id ");
        if ($sql == 1){
            header("location:contrato1.php");
        } else {
            echo "<div class='alert alert-danger'> Error al modificar los campos </div>";
        }
    }else 
        echo "<div class='alert alert-warning'> Complete todo los campos </div>";
}

?>
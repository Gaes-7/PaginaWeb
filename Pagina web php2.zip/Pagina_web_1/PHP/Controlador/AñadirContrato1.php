<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["Contrato"]) and !empty($_POST["fechaI"]) and !empty($_POST["fechaF"]) and !empty($_POST["Salario"]) and !empty($_POST["Banco"])){
     
        $contrato=$_POST["Contrato"];
        $FechaI=$_POST["fechaI"];
        $FechaF=$_POST["fechaF"];
        $salario=$_POST["Salario"];
        $banco=$_POST["Banco"];

        $sql=$conexion->query(" insert into contratoemp(TipoContrato, FechaInicio, FechaFin, Salario, Banco)values
        ('$contrato','$FechaI','$FechaF', '$salario','$banco')");
        if ($sql==1){
            echo '<div class="alert alert-success">Contrato Registrado Correctamente</div>';
        }else {
        
            echo '<div class="alert alert-danger">Error Al Registrar Contrato</div>';
        }


    }else
        echo '<div class="alert alert-warning">Alguno de los campones estan vacios</div>';

}

?>
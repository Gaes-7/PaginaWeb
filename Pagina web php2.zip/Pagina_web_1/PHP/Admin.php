<!Doctype html>
<html>
<head>
    <meta charset="UFT-8">
    <meta name="Viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="Imagen1.jpg" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../Css/estilo.css">
    <script type="Text/JavaScript"></script>
    <title>Topografic Service</title>
    <script src="https://kit.fontawesome.com/946a6ba5b0.js" crossorigin="anonymous"></script>
</head>
<body>
    <header class="header">
        <div class="Logo">
            <img src="../Logo.jpeg" alt="Logo de la compañia" width="100px" height="100px">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="../PHP/proyectos1.php" class="nav-limk">Proyectos</a></li>
            </ul>
        </nav>
        <a href="../index.html"><i class="fas fa-user"></i></a>
    </header>
    
    <main>
        <section class="contenedor sobre-nosotros">
            <h2 class="titulo">Nuestros Servicios</h2>
            <div class="contenedor-sobre-nosotros">
                <img src="../Img/banner.jpg" width="500px" alt="">
                <div class="contenido-texto">
                    <h3><span>1</span>Los Mejores Servicios</h3>
                    <p>Empresa Especializada en servicios topograficos con gran experiencia y amplica cantidad de empleados, maquinaria etc.</p>
                    <h3><span>2</span>Nuestro material</h3>
                    <p>Empresa Especializada en servicios topograficos con gran experiencia y amplica cantidad de empleados, maquinaria etc.</p>
                    <h3><span>3</span>Topografia</h3>
                    <p>Empresa Especializada en servicios topograficos con gran experiencia y amplica cantidad de empleados, maquinaria etc.</p>
                </div>
            </div>
        </section>
        <section class="portafolio">
            <div class="contenedor">
                <h2 class="titulo">Portafolio</h2>
                <div class="galeria-port">
                    <div class="imagen-port">
                        <img src="../Img/img1.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="../Img/img2.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="../Img/img3.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="../Img/img4.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="../Img/img5.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="../Img/img6.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="../Img/img7.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                    <div class="imagen-port">
                        <img src="../Img/img8.jpg" alt="">
                        <div class="hover-galeria">
                            <img src="../Img/selection1.png" alt="">
                            <a href="https://tuequipo.co/categoria/topografia"">clic</a>
                            <p>Nuestros Proyectos</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="clientes contenedor">
            <h2 class="titulo">Que dicen nuestros clientes</h2>
            <div class="cards">
                <div class="card">
                    <img src="../Img/img9.jpg" alt="">
                    <div class="contenido-texto-card">
                        <h4>Cliente 1</h4>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Blanditiis iste aliquam ex ut vero neque illum quasi ab tenetur architecto ducimus explicabo, sed velit harum, magnam, incidunt odit ad maxime.</p>
                    </div>
                </div>
                <div class="card">
                    <img src="../Img/img10.jpg" alt="">
                    <div class="contenido-texto-card">
                        <h4>Cliente 2</h4>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Officia, culpa velit. Deleniti qui sunt culpa excepturi, iusto temporibus quas. Debitis provident molestias harum hic, facere error officia aliquam eius architecto!</p>
                    </div>
                </div>       
            </div>
        </section>
        <section class="about-service">
            <div class="contenedor">
                <h2 class="titulo">Nuestros Servicios</h2>
                <div class="servicio-cont">
                    <div class="servicio-ind">
                        <img src="../Img/servicio1.png" alt="">
                        <h3>Proyectos realizados</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt, hic? Consectetur perferendis, exercitationem id suscipit earum laborum assumenda eveniet dolor tempore, deserunt ad quibusdam, ea soluta accusamus omnis nihil asperiores.</p>
                    </div>
                    <div class="servicio-ind">
                        <img src="../Img/servicio2.jpg" alt="">
                        <h3>Servicos</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt, hic? Consectetur perferendis, exercitationem id suscipit earum laborum assumenda eveniet dolor tempore, deserunt ad quibusdam, ea soluta accusamus omnis nihil asperiores.</p>
                    </div>
                    <div class="servicio-ind">
                        <img src="../Img/servicio3.jpg" alt="">
                        <h3>Nuestros empleados</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt, hic? Consectetur perferendis, exercitationem id suscipit earum laborum assumenda eveniet dolor tempore, deserunt ad quibusdam, ea soluta accusamus omnis nihil asperiores.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="contenedor-footer">
           <div class="content-foo">
                <h4>Mapa de sitio</h4>
                <p><a href="Mapa de sitio.html">Mapa de sitio</a></p>
           </div>
           <div class="content-foo">
                <h4>email</h4>
                <p>serviciostopografic1@hotmail.com</p>
       </div> 
       <div class="content-foo">
            <h4>Redes</h4>
            <section class="buttons">
                <a href="https://www.facebook.com/profile.php?id=100092641494792" class="fa fa-facebook"></a>
                <a href="https://twitter.com/STopografi83139" class="fa fa-twitter"></a>
                <a href="https://www.instagram.com/stopograficos/?__coig_restricted=1" class="fa fa-instagram"></a>
            </section>
            
        </div>  
        </div>
        <h2 class="titulo-final">&copy; Servicios Topograficos | Gaes 7</h2>
    </footer>
</body>
</html>
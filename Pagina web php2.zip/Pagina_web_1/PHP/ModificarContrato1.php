<?php
include ("Modelo/Conexion.php");
$id = $_GET["id"];

$sql=$conexion->query(" select * from contratoemp where idContratoEmp=$id ");

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificados Laborales</title>
    <link rel="icon" href="../recursos1.jpg">
    <link rel="stylesheet" href="../css/certificado.css" />
    <!-- Font Awesome Cdn Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/946a6ba5b0.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
        <nav>
            <div class="navbar">
                <a href="index.html" class="btn btn-primary">Inicio</a>
                <div class="logo">
                    <img src="../recursos9.png" alt="">
                    <h1>Maria
                        lopez
                    </h1>
                </div>
                <ul>
                    <li><a href="contrato1.php">
                            <i class="fas fa-user"></i><br>
                            <span class="nav-item">Contratos</span>
                        </a>
                    </li>
                    <li><a href="certificados1.php">
                            <i class="fas fa-chart-bar"></i><br>
                            <span class="nav-item">Certificados</span>
                        </a>
                    </li>
                    <li><a href="permisos1.php">
                            <i class="fas fa-tasks"></i><br>
                            <span class="nav-item">Permisos</span>
                        </a>
                    </li>
                    <li><a href="incapacidades1.php">
                            <i class="fab fa-dochub"></i>
                            <span class="nav-item">Incapacidades</span>
                        </a>
                    </li>
                    <li><a href="#">
                            <i class="fas fa-cog"></i>
                            <span class="nav-item">Configuracion</span>
                        </a>
                    </li>
                    </a>
                    </li>
                    <li><a href="../index.html" class="logout">
                            <i class="fas fa-sign-out-alt"></i><br>
                            <span class="nav-item">Cerrar sesion</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <section class="main">
            <div class="main-top">
                <p>Consulta tus documentos</p>
            </div>
            <form class="col-3 p-3 m-auto" Method="POST">
        <h2 class="text-center text-secondary">Modificar contrato</h2><br>
        <input type="hidden" name="id" value="<?= $_GET["id"] ?>">
        <?php
        include "Controlador/ModificarContrato.php";
        while ($datos=$sql->fetch_object()){?>
            <div class="mb-3">
                <label class="form-label">Tipo Contrato</label>
                <input type="text" class="form-control" name="contrato" value="<?= $datos->TipoContrato ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Inicio</label>
                <input type="date" class="form-control" name="fechaI" value="<?= $datos->FechaInicio ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha De Fin</label>
                <input type="date" class="form-control" name="fechaF" value="<?= $datos->FechaFin ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Salario</label>
                <input type="text" class="form-control" name="salario" value="<?= $datos->Salario ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Banco</label>
                <input type="text" class="form-control" name="banco" value="<?= $datos->Banco ?>">
            </div>
        <?php }
        ?>

        <button type="submit" class="btn btn-primary" Name="btnañadir" value="ok">Modificar Estado Del Contrato</button>
    </form>
</body>

</html>
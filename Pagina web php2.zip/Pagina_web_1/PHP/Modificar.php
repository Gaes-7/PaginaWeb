<?php
include ("Modelo/Conexion.php");
$id = $_GET["id"];

$sql=$conexion->query(" select * from cliente where idCliente=$id ");

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar</title>
    <link rel="stylesheet" href="../Css/Proyectos2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
<header class="header">
        <div class="Logo">
            <img src="../Logo.jpeg" alt="Logo de la compañia" width="100px" height="100px">
        </div>
        <nav class="nav-links">
                <ul>
                    <li><a href="../PHP/Admin.php">Inicio</a></li>
                    <li><a href="../PHP/Proyectos2.php">Consultar empleado</a></li>
                </ul>
        </nav>
        <i class="fas fa-user"></i>
</header>
    <form class="col-3 p-3 m-auto" Method="POST">
        <h2 class="text-center text-secondary">Modificar Clientes</h2>
        <input type="hidden" name="id" value="<?= $_GET["id"] ?>">
        <?php
        include "Controlador/Modificar.php";
        while ($datos=$sql->fetch_object()){?>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Nombre Del Cliente</label>
                <input type="text" class="form-control" name="nombre" value="<?= $datos->NomCliente ?>">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Apellido Del Cliente</label>
                <input type="text" class="form-control" name="apellido" value="<?= $datos->ApeCliente ?>">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Telefono</label>
                <input type="text" class="form-control" name="telefono" value="<?= $datos->Telefono ?>">
            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Correo</label>
                <input type="text" class="form-control" name="correo" value="<?= $datos->Correo ?>">
            </div>
        <?php }
        ?>

        <button type="submit" class="btn btn-primary" Name="btnañadir" value="ok">Modificar Cliente</button>
    </form>
</body>

</html>
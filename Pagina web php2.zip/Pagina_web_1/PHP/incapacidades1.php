<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificados Laborales</title>
    <link rel="icon" href="../recursos1.jpg">
    <link rel="stylesheet" href="../css/certificado.css" />
    <!-- Font Awesome Cdn Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/946a6ba5b0.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
        <nav>
            <div class="navbar">
                <a href="index.html" class="btn btn-primary">Inicio</a>
                <div class="logo">
                    <img src="../recursos9.png" alt="">
                    <h1>Maria
                        lopez
                    </h1>
                </div>
                <ul>
                    <li><a href="contrato1.php">
                            <i class="fas fa-user"></i><br>
                            <span class="nav-item">Contratos</span>
                        </a>
                    </li>
                    <li><a href="certificados1.php">
                            <i class="fas fa-chart-bar"></i><br>
                            <span class="nav-item">Certificados</span>
                        </a>
                    </li>
                    <li><a href="permisos1.php">
                            <i class="fas fa-tasks"></i><br>
                            <span class="nav-item">Permisos</span>
                        </a>
                    </li>
                    <li><a href="incapacidades1.php">
                            <i class="fab fa-dochub"></i>
                            <span class="nav-item">Incapacidades</span>
                        </a>
                    </li>
                    <li><a href="#">
                            <i class="fas fa-cog"></i>
                            <span class="nav-item">Configuracion</span>
                        </a>
                    </li>
                    </a>
                    </li>
                    <li><a href="../index.html" class="logout">
                            <i class="fas fa-sign-out-alt"></i><br>
                            <span class="nav-item">Cerrar sesion</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <section class="main">
            <div class="main-top">
                <p>Consulta tus documentos</p>
            </div>
        <?php
    include "Modelo/Conexion.php";
    include "Controlador/EliminarIncapacidad.php";
    ?>
        <div class="container-fluid ">
            <form class="col-15 p-3" Method="POST">
                <h2 class="text-center text-secondary">Registro De Incapacidad</h2>
                <div class="mb-3">
                    <label class="form-label">Nombre Del Empleado</label>
                    <input type="text" class="form-control" Name="nombre">
                </div>
                <div class="mb-3">
                    <label class="form-label">Fecha Inicio Incapacidad</label>
                    <input type="date" class="form-control" Name="fechaI">
                </div>
                <div class="mb-3">
                    <label class="form-label">Fecha Fin Incapacidad</label>
                    <input type="date" class="form-control" Name="fechaF">
                </div>
                <div class="mb-3">
                    <label class="form-label">Numero Incapacidad</label>
                    <input type="text" class="form-control" Name="numero">
                </div>
                <div class="mb-3">
                    <label class="form-label">Duracion</label>
                    <input type="text" class="form-control" Name="Duracion">
                </div>
                <center><button type="submit" class="btn btn-primary" Name="btnañadir" value="ok">Añadir</button></center>
            </form>
            <div class="col-15 p-3">
                <h2 class="text-center text-secondary">Estado Incapacidad</h2><br>
                <table class="table">
                    <thead class="bg-info">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">ID Empleado</th>
                            <th scope="col">Fecha De Inicio</th>
                            <th scope="col">Fecha De Fin</th>
                            <th scope="col">Numero De Incapacidades</th>
                            <th scope="col">Duracion</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <?php 
     include "Modelo/Conexion.php";
     include "Controlador/AñadirIncapacidad.php";
     ?><br>
                    <tbody>
                        <?php
    include "Modelo/Conexion.php";
    $sql=$conexion->query(" select * from incapacidades");
    while($datos=$sql->fetch_object()){?>

                        <tr>
                            <td><?= $datos->idIncapacidades ?></td>
                            <td><?= $datos->idIncapacidades ?></td>
                            <td><?= $datos->FechaInicio ?></td>
                            <td><?= $datos->FechaFin ?></td>
                            <td><?= $datos->NumIncapacidades ?></td>
                            <td><?= $datos->Duracion ?></td>
                            <td>
                                <a href="ModificarIncapacidad.php?id=<?= $datos->idIncapacidades ?>" class="btn btn small btn-warning"><i
                                        class="fa-solid fa-user-pen"></i></a>
                                <a href="incapacidades1.php?id=<?= $datos->idIncapacidades ?>" class="btn btn small btn-danger"><i
                                        class="fa-solid fa-user-slash"></i></a>
                            </td>
                        </tr>
                        <?php 
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
        </section>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
        </script>
</body>

</html>
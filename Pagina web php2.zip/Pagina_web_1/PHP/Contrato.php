<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="../Css/Proyectos2.css">
    <title>Consultar Proyectos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/946a6ba5b0.js" crossorigin="anonymous"></script>

</head>

<body>
    <header class="header">
        <div class="Logo">
            <img src="../Logo.jpeg" alt="Logo de la compañia" width="100px" height="100px">
        </div>
        <nav class="nav-links">
            <ul>
                <li><a href="../PHP/Admin.php">Inicio</a></li>
                <li><a href="../PHP/Proyectos1.php">Proyectos</a></li>
                <li><a href="../PHP/Proyectos2.php">Consultar Cliente</a></li>
            </ul>
        </nav>
        <i class="fas fa-user">
    </header>
    <?php
include "Modelo/Conexion.php";
include "Controlador/EliminarContratoP.php";
?>
    <div class="container-fluid row">
        <form class="col-3 p-3" Method="POST">
            <h2 class="text-center text-secondary">Registro De Contrato</h2>
            <div class="mb-3">
                <label class="form-label">Nombre Cliente</label>
                <input type="text" class="form-control" Name="nombre">
            </div>
            <div class="mb-3">
                <label class="form-label">Tipo Contrato</label>
                <input type="text" class="form-control" Name="contrato">
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Inicio</label>
                <input type="date" class="form-control" Name="fechaI">
            </div>
            <div class="mb-3">
                <label class="form-label">Fecha Fin</label>
                <input type="date" class="form-control" Name="fechaF">
            </div>
            <div class="mb-3">
                <label class="form-label">Valor</label>
                <input type="text" class="form-control" Name="valor">
            </div>
            <div class="mb-3">
                <label class="form-label">Clausula</label>
                <input type="text" class="form-control" Name="clausula">
            </div>
            <button type="submit" class="btn btn-primary" Name="btnañadir" value="ok">Añadir</button>
        </form>
        <div class="col-8 p-3">
            <h2 class="text-center text-secondary">Contratos</h2><br>
            <table class="table">
                <thead class="bg-info">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">ID Cliente</th>
                        <th scope="col">ID Tipo Proyecto</th>
                        <th scope="col">Fecha Inicio</th>
                        <th scope="col">Fecha Fin</th>
                        <th scope="col">Valor</th>
                        <th scope="col">Clausula</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <?php 
     include "Modelo/Conexion.php";
     include "Controlador/AñadirContratoP.php";
     ?><br>
                <tbody>
                    <?php
    include "Modelo/Conexion.php";
    $sql=$conexion->query(" select * from contratoproyecto");
    while($datos=$sql->fetch_object()){?>

                    <tr>
                        <td><?= $datos->idContratoProyecto ?></td>
                        <td><?= $datos->idContratoProyecto ?></td>
                        <td><?= $datos->idContratoProyecto ?></td>
                        <td><?= $datos->FechaInicio ?></td>
                        <td><?= $datos->FechaFin ?></td>
                        <td><?= $datos->Valor ?></td>
                        <td><?= $datos->Clausula ?></td>
                        <td>
                            <a href="ModificarContratoP.php?id=<?= $datos->idContratoProyecto ?>"
                                class="btn btn small btn-warning"><i class="fa-solid fa-user-pen"></i></a>
                            <a href="contrato.php?id=<?= $datos->idContratoProyecto ?>" class="btn btn small btn-danger"><i
                                    class="fa-solid fa-user-slash"></i></a>
                        </td>
                    </tr>
                    <?php 
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>
</body>

</html>
<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["fechaI"]) and !empty($_POST["fechaF"]) and !empty($_POST["numero"]) and !empty($_POST["Duracion"])){
     
        $fechaI=$_POST["fechaI"];
        $fechaF=$_POST["fechaF"];
        $numero=$_POST["numero"];
        $duracion=$_POST["Duracion"];

        $sql=$conexion->query(" insert into incapacidades(FechaInicio, FechaFin, NumIncapacidades, Duracion)values
        ('$fechaI','$fechaF','$numero','$duracion')");
        if ($sql==1){
            echo '<div class="alert alert-success">Incapacidad Registrada Correctamente</div>';
        }else {
        
            echo '<div class="alert alert-danger">Error Al Registrar Incapacidad</div>';
        }


    }else
        echo '<div class="alert alert-warning">Alguno de los campones estan vacios</div>';

}

?>
<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["numero"]) and !empty($_POST["Estado"])){
     
        $id = $_POST["id"];
        $numero=$_POST["numero"];
        $estado=$_POST["Estado"];

        $sql=$conexion->query(" update certificados set NumCertificado=$numero, EstadoCertificadp='$estado' where idCertificado=$id ");
        if ($sql == 1){
            header("location:certificados1.php");
        } else {
            echo "<div class='alert alert-danger'> Error al modificar los campos </div>";
        }
    }else 
        echo "<div class='alert alert-warning'> Complete todo los campos </div>";
}

?>
<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["numero"]) and !empty($_POST["Duracion"])){
     
        $id = $_POST["id"];
        $numero=$_POST["numero"];
        $duracion=$_POST["Duracion"];

        $sql=$conexion->query(" update permisos set NumPermiso=$numero, Duracion='$duracion' where idPermisos=$id ");
        if ($sql == 1){
            header("location:permisos1.php");
        } else {
            echo "<div class='alert alert-danger'> Error al modificar los campos </div>";
        }
    }else 
        echo "<div class='alert alert-warning'> Complete todo los campos </div>";
}

?>
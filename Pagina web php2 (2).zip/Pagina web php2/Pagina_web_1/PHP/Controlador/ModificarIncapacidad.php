<?php

if (!empty($_POST["btnañadir"])){
    if (!empty($_POST["fechaI"]) and !empty($_POST["fechaF"]) and !empty($_POST["numero"]) and !empty($_POST["Duracion"])){
        $id = $_POST["id"];
        $fechaI=$_POST["fechaI"];
        $fechaF=$_POST["fechaF"];
        $numero=$_POST["numero"];
        $duracion=$_POST["Duracion"];

        $sql=$conexion->query(" update incapacidades set FechaInicio='$fechaI', FechaFin='$fechaF', NumIncapacidades=$numero, Duracion='$duracion' where idIncapacidades=$id ");
        if ($sql == 1){
            header("location:incapacidades1.php");
        } else {
            echo "<div class='alert alert-danger'> Error al modificar los campos </div>";
        }
    }else 
        echo "<div class='alert alert-warning'> Complete todo los campos </div>";
}

?>
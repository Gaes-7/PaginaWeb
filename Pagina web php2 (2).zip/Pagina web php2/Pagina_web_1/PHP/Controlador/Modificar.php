<?php

if (!empty($_POST["btnañadir"])) {
    if (!empty($_POST["nombre"]) and !empty($_POST["apellido"]) and !empty($_POST["telefono"]) and !empty($_POST["correo"])) {
        
        $id=$_POST["id"];
        $nombre=$_POST["nombre"];
        $apellido=$_POST["apellido"];
        $telefono=$_POST["telefono"];
        $correo=$_POST["correo"];

        $sql=$conexion->query(" update cliente set NomCliente='$nombre', ApeCliente='$apellido', Telefono='$telefono', Correo='$correo' where idCliente=$id ");
        if ($sql == 1){
            header("location:Proyectos2.php");
        } else {
            echo "<div class='alert alert-danger'> Error al modificar los campos </div>";
        }
    }else 
        echo "<div class='alert alert-warning'> Complete todo los campos </div>";
}

?>
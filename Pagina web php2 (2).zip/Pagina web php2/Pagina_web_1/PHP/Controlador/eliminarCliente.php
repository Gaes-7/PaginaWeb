<?php

if (!empty($_GET["id"])) {
    $id=$_GET["id"];
    $sql=$conexion->query(" delete from cliente where idCliente=$id ");
    if ($sql == 1) {
        echo '<div class="alert alert-success"> Cliente Eliminado Correctamente </div>';
    } else {
        echo '<div class="alert alert-danger"> Error al eliminar cliente </div>';
    }
    
}


?>
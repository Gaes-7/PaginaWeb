<?php

if (!empty($_GET["id"])) {
    $id=$_GET["id"];
    $sql=$conexion->query(" delete from certificados where idCertificado=$id ");
    if ($sql == 1) {
        echo '<div class="alert alert-success"> Certificado Eliminado Correctamente </div>';
    } else {
        echo '<div class="alert alert-danger"> Error al eliminar certificado </div>';
    }
    
}


?>
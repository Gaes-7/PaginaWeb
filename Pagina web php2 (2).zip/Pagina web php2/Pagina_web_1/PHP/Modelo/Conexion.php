<?php
    
    $conexion= new mysqli("localhost", "root", "", "topografiabd");
    $conexion->set_charset("utf8");

?>
